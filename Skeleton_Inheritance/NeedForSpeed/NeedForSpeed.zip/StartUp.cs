﻿namespace NeedForSpeed
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Motorcycle first = new Motorcycle(22 , 14.05);
            first.Drive(20);
        }
    }
}
