﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PlayersAndMonsters
{
    class Elf : Hero
    {
        public Elf(string userName, int level)
            : base(userName, level)
        {
        }
    }
}
