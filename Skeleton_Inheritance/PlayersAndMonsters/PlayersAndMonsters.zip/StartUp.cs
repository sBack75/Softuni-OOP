﻿namespace PlayersAndMonsters
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            DarkKnight newChamp = new DarkKnight("kolio" , 15);
            System.Console.WriteLine(newChamp);
        }
    }
}